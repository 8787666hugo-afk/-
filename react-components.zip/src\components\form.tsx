import type { ChangeEvent, ReactNode } from 'react';
import type {
  ChoiceOption,
  FieldMessageData,
  FieldName,
  SelectOption,
  SessionData,
} from '../types';
import { FieldMessage, StatusBadge } from './feedback';

/* ============================================================
   FormField：單一欄位（text / email / tel / date / number /
   time / select / textarea / checkbox）
   ============================================================ */

export type FieldKind =
  | 'text'
  | 'email'
  | 'tel'
  | 'date'
  | 'number'
  | 'time'
  | 'select'
  | 'textarea'
  | 'checkbox';

export interface FormFieldProps {
  name: FieldName;
  label: string;
  kind?: FieldKind;
  required?: boolean;
  value: string | boolean;
  placeholder?: string;
  options?: SelectOption[];
  suggestions?: string[];
  maxLength?: number;
  min?: number | string;
  max?: number | string;
  step?: number;
  inputMode?: 'text' | 'numeric' | 'email' | 'tel';
  autoComplete?: string;
  readOnly?: boolean;
  disabled?: boolean;
  spellCheck?: boolean;
  blockPaste?: boolean;
  tip?: ReactNode;
  counter?: ReactNode;
  message?: FieldMessageData | null;
  visible?: boolean;
  full?: boolean;
  dataLabel?: string;
  checkboxLabel?: ReactNode;
  onChange: (value: string | boolean) => void;
  onBlur?: () => void;
}

export function FormField({
  name,
  label,
  kind = 'text',
  required = false,
  value,
  placeholder,
  options,
  suggestions,
  maxLength,
  min,
  max,
  step,
  inputMode,
  autoComplete,
  readOnly,
  disabled,
  spellCheck,
  blockPaste,
  tip,
  counter,
  message,
  visible = true,
  full = false,
  dataLabel,
  checkboxLabel,
  onChange,
  onBlur,
}: FormFieldProps) {
  const classes = ['field'];
  if (full) classes.push('full');
  if (message?.type === 'error') classes.push('invalid');
  if (message?.type === 'good') classes.push('valid');

  const describedBy = [tip ? `tip-${name}` : null, `msg-${name}`]
    .filter(Boolean)
    .join(' ');

  const baseProps = {
    id: name,
    name,
    'aria-invalid': message?.type === 'error' ? true : undefined,
    'aria-describedby': describedBy,
    'aria-required': required || undefined,
    'data-label': dataLabel ?? label,
    onBlur,
  };

  /* ---------- 勾選框（個資同意 / 訂閱） ---------- */
  if (kind === 'checkbox') {
    return (
      <div className={classes.join(' ')} hidden={!visible}>
        <label className="agree" htmlFor={name}>
          <input
            {...baseProps}
            type="checkbox"
            checked={value === true}
            onChange={(event: ChangeEvent<HTMLInputElement>) =>
              onChange(event.target.checked)
            }
          />
          <span>
            {checkboxLabel}
            {required && <span style={{ color: 'var(--err)' }}>（必須勾選）</span>}
          </span>
        </label>
        <FieldMessage name={name} message={message} />
      </div>
    );
  }

  /* ---------- 下拉選單 ---------- */
  if (kind === 'select') {
    return (
      <div className={classes.join(' ')} hidden={!visible}>
        <label className={required ? 'req' : 'opt'} htmlFor={name}>
          {label}
        </label>
        <select
          {...baseProps}
          value={String(value ?? '')}
          disabled={disabled}
          onChange={(event: ChangeEvent<HTMLSelectElement>) =>
            onChange(event.target.value)
          }
        >
          {options?.map((option) => (
            <option key={option.value} value={option.value}>
              {option.label}
            </option>
          ))}
        </select>
        {tip && (
          <div className="tip" id={`tip-${name}`}>
            {tip}
          </div>
        )}
        <FieldMessage name={name} message={message} />
      </div>
    );
  }

  /* ---------- 多行文字 ---------- */
  if (kind === 'textarea') {
    return (
      <div className={classes.join(' ')} hidden={!visible}>
        <label className={required ? 'req' : 'opt'} htmlFor={name}>
          {label}
        </label>
        <textarea
          {...baseProps}
          value={String(value ?? '')}
          placeholder={placeholder}
          maxLength={maxLength}
          readOnly={readOnly}
          disabled={disabled}
          spellCheck={spellCheck}
          onChange={(event: ChangeEvent<HTMLTextAreaElement>) =>
            onChange(event.target.value)
          }
        />
        {counter}
        {tip && (
          <div className="tip" id={`tip-${name}`}>
            {tip}
          </div>
        )}
        <FieldMessage name={name} message={message} />
      </div>
    );
  }

  /* ---------- 單行輸入 ---------- */
  return (
    <div className={classes.join(' ')} hidden={!visible}>
      <label className={required ? 'req' : 'opt'} htmlFor={name}>
        {label}
      </label>
      <input
        {...baseProps}
        type={kind}
        value={String(value ?? '')}
        placeholder={placeholder}
        maxLength={maxLength}
        min={min}
        max={max}
        step={step}
        inputMode={inputMode}
        autoComplete={autoComplete}
        readOnly={readOnly}
        disabled={disabled}
        spellCheck={spellCheck}
        list={suggestions ? `${name}-list` : undefined}
        onPaste={
          blockPaste
            ? (event) => {
                event.preventDefault();
              }
            : undefined
        }
        onChange={(event: ChangeEvent<HTMLInputElement>) =>
          onChange(event.target.value)
        }
      />
      {suggestions && (
        <datalist id={`${name}-list`}>
          {suggestions.map((suggestion) => (
            <option key={suggestion} value={suggestion} />
          ))}
        </datalist>
      )}
      {tip && (
        <div className="tip" id={`tip-${name}`}>
          {tip}
        </div>
      )}
      <FieldMessage name={name} message={message} />
    </div>
  );
}

/* ============================================================
   ChoiceChips：膠囊狀的單選 / 多選群組
   ============================================================ */

export interface ChoiceChipsProps {
  name: FieldName;
  legend: string;
  required?: boolean;
  type?: 'radio' | 'checkbox';
  options: ChoiceOption[];
  value?: string;
  values?: string[];
  message?: FieldMessageData | null;
  full?: boolean;
  onChange: (value: string, checked: boolean) => void;
  onBlur?: () => void;
}

export function ChoiceChips({
  name,
  legend,
  required = false,
  type = 'radio',
  options,
  value,
  values,
  message,
  full = false,
  onChange,
  onBlur,
}: ChoiceChipsProps) {
  const classes = ['field'];
  if (full) classes.push('full');
  if (message?.type === 'error') classes.push('invalid');

  return (
    <div className={classes.join(' ')}>
      <fieldset>
        <legend className={required ? 'req' : 'opt'}>{legend}</legend>
        <div className="choices">
          {options.map((option) => {
            const checked =
              type === 'radio'
                ? value === option.value
                : Boolean(values?.includes(option.value));
            return (
              <label className="chip" key={option.value}>
                <input
                  type={type}
                  name={name}
                  value={option.value}
                  checked={checked}
                  disabled={option.disabled}
                  onChange={(event) => onChange(option.value, event.target.checked)}
                  onBlur={onBlur}
                />
                <span>{option.label}</span>
              </label>
            );
          })}
        </div>
      </fieldset>
      <FieldMessage name={name} message={message} />
    </div>
  );
}

/* ============================================================
   SessionOption：場次卡
   ============================================================ */

export interface SessionOptionProps {
  session: SessionData;
  name?: string;
  checked: boolean;
  onChange: (value: string) => void;
  onBlur?: () => void;
}

export function SessionOption({
  session,
  name = 'session',
  checked,
  onChange,
  onBlur,
}: SessionOptionProps) {
  return (
    <label className="session">
      <input
        type="radio"
        name={name}
        value={session.value}
        checked={checked}
        disabled={session.disabled}
        data-label="場次"
        onChange={() => onChange(session.value)}
        onBlur={onBlur}
      />
      <span className="s-main">
        <span className="s-title">{session.title}</span>
        <span className="s-meta">
          {session.location} ・ <StatusBadge {...session.badge} />
        </span>
      </span>
    </label>
  );
}
