import type { FieldName, RecapRow, SignupFormData } from '../types';

/** 由出生日期計算年齡；格式錯誤回傳 null */
export function ageOf(birth: string): number | null {
  const b = new Date(`${birth}T00:00:00`);
  if (Number.isNaN(b.getTime())) return null;
  const t = new Date();
  let a = t.getFullYear() - b.getFullYear();
  const m = t.getMonth() - b.getMonth();
  if (m < 0 || (m === 0 && t.getDate() < b.getDate())) a -= 1;
  return a;
}

/** 「18 歲（民國 97 年）」；尚未填寫時回傳破折號 */
export function ageText(birth: string): string {
  if (!birth) return '—';
  const a = ageOf(birth);
  const d = new Date(`${birth}T00:00:00`);
  if (a === null || Number.isNaN(d.getTime())) return '—';
  return `${a} 歲（民國 ${d.getFullYear() - 1911} 年）`;
}

export function maskId(s: string): string {
  return s ? `${s.slice(0, 4)}****${s.slice(-2)}` : '';
}

export function serialNo(): string {
  const t = new Date();
  const p = (n: number) => String(n).padStart(2, '0');
  return `BF${t.getFullYear()}${p(t.getMonth() + 1)}${p(t.getDate())}-${String(
    Math.floor(Math.random() * 9000) + 1000,
  )}`;
}

/** 把表單狀態整理成完成畫面的摘要列 */
export function collectRecap(d: SignupFormData): RecapRow[] {
  const rows: RecapRow[] = [];
  const add = (key: string, value: string) => rows.push({ key, value });
  const text = (name: FieldName) => String(d[name] ?? '').trim();

  add('姓名', text('name'));
  add('英文姓名', text('nickname') || '—');
  add('性別', d.gender);
  add('出生年月日', `${text('birth')}（${ageOf(text('birth')) ?? '—'} 歲）`);
  add('證號類型', d.idType === 'arc' ? '居留證／統一證號' : '本國身分證');
  add('證件號碼', maskId(text('idno').toUpperCase()));
  add('手機號碼', text('mobile'));
  add('市話', text('phone') || '—');
  add('電子信箱', text('email'));
  add('緊急聯絡人', text('emergency') || '—');
  add('身分別', d.role);

  if (d.role === '學生') {
    add('學校', text('school'));
    add('系所', text('dept'));
    add('年級', text('grade'));
    add('學號', text('studentId') || '—');
  } else if (d.role === '在職') {
    add('公司單位', text('company'));
    add('職稱', text('jobTitle'));
    add('工作年資', text('years') !== '' ? `${text('years')} 年` : '—');
  } else {
    add('身分別說明', text('roleNote'));
  }

  add('報名場次', d.session);
  add('參加人數', `${text('people')} 人`);
  if (Number(text('people')) > 1) add('同行者', text('companions'));
  add('預計抵達時間', text('arrive'));
  add('接駁車', d.shuttle + (d.shuttle === '需要' ? `（${text('shuttleStop')}）` : ''));
  add('餐點需求', d.meal);
  add('無障礙需求', d.access || '無特殊需求');
  add('得知管道', d.source.join('、'));
  add('備註', text('note') || '—');
  add('訂閱活動資訊', d.news ? '願意' : '不願意');

  return rows;
}
