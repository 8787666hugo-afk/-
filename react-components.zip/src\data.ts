import type {
  ActionLink,
  ChoiceOption,
  Fact,
  FieldName,
  KeyValueItem,
  NavCardData,
  NavItem,
  ProjectData,
  SelectOption,
  SessionData,
  SignupFormData,
  SkillItem,
  TagItem,
  TimelineEntry,
} from './types';

/* ============================================================
   全站共用
   ============================================================ */

export const SITE = {
  name: '劉育齊 Hugo',
  logoText: 'HL',
  tagline: 'SAP ERP 顧問實習生',
  email: '8787666hugo@gmail.com',
  year: 2026,
  footerNote:
    '本站為靜態單一檔案網頁；表單所填資料僅顯示於您的瀏覽器，不會上傳至任何伺服器。',
};

export const NAV_ITEMS: NavItem[] = [
  { id: 'tab-home', label: '首頁', href: '#/home' },
  { id: 'tab-resume', label: '個人簡介', href: '#/resume' },
  { id: 'tab-form', label: '說明會表單', href: '#/form' },
];

/* ============================================================
   首頁
   ============================================================ */

export const HERO = {
  avatarText: 'HL',
  name: '劉育齊　Hugo Liu',
  role: 'SAP ERP 顧問實習生 ・ 資訊管理系學生',
  lede:
    '高職電子科出身，現就讀國立勤益科技大學資訊管理系。在國立中央大學 ERP 學會擔任 SAP 顧問實習生，參與製造業客戶的 SAP S/4HANA 導入專案，專長是把商業流程問題拆解成可落地的系統方案。目標是成為 ERP 導入顧問。',
  actions: [
    { label: '看我的個人簡介', href: '#/resume', variant: 'primary' },
    { label: '前往說明會報名', href: '#/form', variant: 'ghost' },
  ] as ActionLink[],
};

export const FACTS: Fact[] = [
  { value: 'S/4HANA', label: '實際客戶導入專案' },
  { value: 'SD / MM / PP', label: '模組實作經驗' },
  { value: 'ERP 規劃師', label: '大一取得證照' },
  { value: 'ABAP + Python', label: '整合層自行開發' },
];

export const NAV_CARDS: NavCardData[] = [
  {
    icon: '📄',
    title: '個人簡介',
    description: '學歷、實習經歷、SAP 專案與技術能力的完整履歷。',
    cta: '查看履歷 →',
    href: '#/resume',
  },
  {
    icon: '📝',
    title: '說明會表單',
    description: '線上報名說明會場次，含完整欄位驗證與防呆設計。',
    cta: '立即報名 →',
    href: '#/form',
  },
];

/* ============================================================
   個人簡介
   ============================================================ */

export const TIMELINE: TimelineEntry[] = [
  {
    period: '現職',
    title: 'SAP 顧問實習生',
    org: '國立中央大學 ERP 學會',
    bullets: [
      '參與製造業客戶 SAP S/4HANA 實際導入專案，負責需求規劃（PP）相關設計',
      '自行開發 SAP 與外部 AI 服務的整合層，並完成 SD-to-PP 整合流程的客戶簡報',
    ],
  },
  {
    period: '在學',
    title: '資訊管理系 學生',
    org: '國立勤益科技大學',
    bullets: [
      '大一取得 ERP 規劃師證照',
      '在教學環境中從零建置完整企業組織架構並完成 SD 銷售流程實作',
    ],
  },
  {
    period: '校園服務',
    title: '宿舍幹部（衛生組）',
    org: '國立勤益科技大學 學生宿舍',
    bullets: ['負責固定值勤時段與每月幹部會議，執行例行環境檢查作業'],
  },
  {
    period: '高職階段',
    title: '電子科 ・ 全國電子類競賽 第二名',
    org: '台北城市科技大學 舉辦',
    bullets: ['電子電路與硬體實作訓練，奠定系統層級的技術思考基礎'],
  },
];

export const PROJECTS: ProjectData[] = [
  {
    title: '製造業客戶 S/4HANA 導入｜AI 輔助需求預測',
    meta: '角色：需求預測架構設計與整合開發 ・ 模組：PP / MM / SD',
    paragraphs: [
      '客戶的核心困境是結構性的時間落差：關鍵原料採購前置期約 3 個月，但客戶期望交期僅 1 個月。這使得「預測準確度」直接決定備料策略能否成立。',
      '我設計的是混合式三階段架構，刻意保留 SAP 統計基準線作為備援，而不是讓 AI 取代整條預測邏輯——這樣才具備可解釋性，AI 服務異常時也能優雅降級。',
    ],
    stages: [
      { label: 'Stage 1｜基準線', text: '以 SAP 標準統計預測產出基礎需求量' },
      { label: 'Stage 2｜殘差修正', text: 'Python 模型補捉統計方法抓不到的外部事件訊號' },
      { label: 'Stage 3｜寫回 SAP', text: '透過 BAPI 寫回計畫獨立需求，驅動 MPS／MRP' },
    ],
    tags: [
      { text: 'ABAP 自建程式', key: true },
      { text: 'BAPI 整合', key: true },
      { text: 'Python 服務' },
      { text: 'Gemini API' },
      { text: '43 個月歷史資料訓練' },
      { text: '80/20 時序切分' },
      { text: '信賴門檻人工覆核機制' },
    ],
  },
  {
    title: '企業組織架構與 SD 銷售流程 從零建置',
    meta: '教學實作環境 ・ 情境設定：馬達製造商採用數量合約',
    paragraphs: [
      '完整建立公司代碼、控制範圍、工廠、採購組織、銷售組織、配銷通路、產品線及各層指派關係，並串起物料主檔 → 儲存地點 → 庫存 → 銷售訂單的完整鏈路。',
      '過程中自行診斷並解決工廠與公司代碼指派缺漏、MM 期間未開通等典型阻礙，能明確指出每個錯誤訊息背後真正缺少的前置設定。',
    ],
  },
];

export const SKILLS: SkillItem[] = [
  { category: 'SAP 模組', detail: 'SD 銷售與配銷、MM 物料管理、PP 生產規劃（MPS／MRP、計畫獨立需求）' },
  { category: 'SAP 設定', detail: '企業組織架構建置、Sales Area 指派、物料主檔、期間開通、錯誤根因診斷' },
  { category: '開發整合', detail: 'ABAP 自建程式、BAPI 呼叫、RFC 目的地設定、Python 服務、REST API、LLM 結構化輸出' },
  { category: '顧問技能', detail: '商業流程分析、痛點分層與優先級、專案範疇界定、效益論證、客戶簡報' },
  { category: '語言', detail: '中文（母語）、英文（TOEIC 準備中，並規劃海外研習計畫）' },
];

export const TAGS: TagItem[] = [
  { text: 'SAP S/4HANA', key: true },
  { text: 'ERP 導入', key: true },
  { text: '需求規劃' },
  { text: 'MRP' },
  { text: 'ABAP' },
  { text: 'Python' },
  { text: '流程分析' },
  { text: '製造業' },
];

export const CONTACT_ITEMS: KeyValueItem[] = [
  { term: 'Email', value: '8787666hugo@gmail.com', href: 'mailto:8787666hugo@gmail.com' },
  { term: '手機', value: '09XX-XXX-XXX', href: 'tel:+886900000000', note: '請自行替換' },
  { term: '所在地', value: '台灣 ・ 台中' },
  { term: '求職方向', value: 'ERP／SAP 導入顧問' },
];

export const EDUCATION_ITEMS: KeyValueItem[] = [
  { term: '大學', lines: ['國立勤益科技大學', '資訊管理系'] },
  { term: '高職', value: '電子科' },
  { term: '證照', value: 'ERP 規劃師' },
];

/* ============================================================
   說明會場次
   ============================================================ */

export const SESSIONS: SessionData[] = [
  {
    code: 'A',
    value: 'A｜2026-10-03(六) 10:00-12:00 台中場',
    title: 'A 場｜10 月 3 日（六）10:00–12:00',
    location: '台中市｜勤益科大 圖書館 3F 國際會議廳',
    badge: { tone: 'ok', text: '尚有 24 位' },
  },
  {
    code: 'B',
    value: 'B｜2026-10-10(六) 14:00-16:00 台北場',
    title: 'B 場｜10 月 10 日（六）14:00–16:00',
    location: '台北市｜中央大學 台北推廣中心 5F',
    badge: { tone: 'warn', text: '僅剩 3 位' },
  },
  {
    code: 'C',
    value: 'C｜2026-10-17(六) 10:00-12:00 線上場',
    title: 'C 場｜10 月 17 日（六）10:00–12:00',
    location: '線上 Microsoft Teams（報名後寄送連結）',
    badge: { tone: 'ok', text: '尚有 100 位' },
  },
  {
    code: 'D',
    value: 'D｜2026-10-24(六) 高雄場',
    title: 'D 場｜10 月 24 日（六）14:00–16:00',
    location: '高雄市｜軟體園區 2F',
    badge: { tone: 'danger', text: '已額滿' },
    disabled: true,
  },
];

/* ============================================================
   表單選項
   ============================================================ */

export const GENDER_OPTIONS: ChoiceOption[] = [
  { value: '男', label: '男' },
  { value: '女', label: '女' },
  { value: '不願透露', label: '不願透露' },
];

export const ID_TYPE_OPTIONS: ChoiceOption[] = [
  { value: 'id', label: '本國身分證' },
  { value: 'arc', label: '居留證／統一證號' },
];

export const ROLE_OPTIONS: ChoiceOption[] = [
  { value: '學生', label: '在校學生' },
  { value: '在職', label: '在職人士' },
  { value: '待業／轉職', label: '待業／轉職' },
  { value: '其他', label: '其他' },
];

export const SHUTTLE_OPTIONS: ChoiceOption[] = [
  { value: '需要', label: '需要' },
  { value: '不需要', label: '不需要' },
];

export const SOURCE_OPTIONS: ChoiceOption[] = [
  { value: '學校公告', label: '學校公告' },
  { value: '系所老師', label: '系所老師' },
  { value: '社群媒體', label: '社群媒體' },
  { value: '朋友推薦', label: '朋友推薦' },
  { value: '電子報', label: '電子報' },
  { value: '其他', label: '其他' },
];

export const GRADE_OPTIONS: SelectOption[] = [
  { value: '', label: '請選擇' },
  { value: '一年級', label: '一年級' },
  { value: '二年級', label: '二年級' },
  { value: '三年級', label: '三年級' },
  { value: '四年級', label: '四年級' },
  { value: '延畢／研究所', label: '延畢／研究所' },
];

export const SHUTTLE_STOP_OPTIONS: SelectOption[] = [
  { value: '', label: '請選擇' },
  { value: '台中高鐵站（烏日）', label: '台中高鐵站（烏日）' },
  { value: '台中火車站', label: '台中火車站' },
  { value: '太原車站', label: '太原車站' },
  { value: '台北車站 東三門', label: '台北車站 東三門' },
];

export const MEAL_OPTIONS: SelectOption[] = [
  { value: '', label: '請選擇' },
  { value: '葷食', label: '葷食' },
  { value: '素食', label: '素食' },
  { value: '不需餐點', label: '不需餐點' },
  { value: '其他（請於下方備註說明）', label: '其他（請於下方備註說明）' },
];

export const ACCESS_OPTIONS: SelectOption[] = [
  { value: '', label: '無特殊需求' },
  { value: '需要輪椅席位', label: '需要輪椅席位' },
  { value: '需要前排座位', label: '需要前排座位' },
  { value: '需要手語或字幕協助', label: '需要手語或字幕協助' },
  { value: '其他（請於備註說明）', label: '其他（請於備註說明）' },
];

export const SCHOOL_SUGGESTIONS = [
  '國立勤益科技大學',
  '國立中央大學',
  '國立台灣科技大學',
  '國立雲林科技大學',
  '逢甲大學',
  '東海大學',
];

/* ============================================================
   表單初始值與欄位順序
   ============================================================ */

export function createInitialForm(): SignupFormData {
  return {
    name: '',
    nickname: '',
    gender: '',
    birth: '',
    idType: 'id',
    idno: '',
    mobile: '',
    phone: '',
    email: '',
    email2: '',
    emergency: '',
    role: '',
    school: '',
    dept: '',
    grade: '',
    studentId: '',
    company: '',
    jobTitle: '',
    years: '',
    roleNote: '',
    session: '',
    people: '1',
    companions: '',
    arrive: '',
    shuttle: '',
    shuttleStop: '',
    meal: '',
    access: '',
    source: [],
    note: '',
    agree: false,
    news: false,
  };
}

export const FIELD_LABELS: Record<FieldName, string> = {
  name: '姓名',
  nickname: '英文姓名',
  gender: '性別',
  birth: '出生年月日',
  idType: '證號類型',
  idno: '證件號碼',
  mobile: '手機號碼',
  phone: '市話',
  email: '電子信箱',
  email2: '確認電子信箱',
  emergency: '緊急聯絡人',
  role: '身分別',
  school: '學校名稱',
  dept: '系所',
  grade: '年級',
  studentId: '學號',
  company: '公司名稱',
  jobTitle: '職稱',
  years: '工作年資',
  roleNote: '身分別說明',
  session: '場次',
  people: '參加人數',
  companions: '同行者姓名',
  arrive: '預計抵達時間',
  shuttle: '接駁車',
  shuttleStop: '接駁上車地點',
  meal: '餐點需求',
  access: '無障礙需求',
  source: '得知管道',
  note: '備註',
  agree: '個資同意',
  news: '訂閱活動資訊',
};

/** 驗證與錯誤摘要的固定順序（與原檔一致） */
export const ORDER: FieldName[] = [
  'name',
  'nickname',
  'gender',
  'birth',
  'idType',
  'idno',
  'mobile',
  'phone',
  'email',
  'email2',
  'emergency',
  'role',
  'school',
  'dept',
  'grade',
  'studentId',
  'company',
  'jobTitle',
  'years',
  'roleNote',
  'session',
  'people',
  'companions',
  'arrive',
  'shuttle',
  'shuttleStop',
  'meal',
  'access',
  'source',
  'note',
  'agree',
];

/** 進度條的固定必填欄位 */
export const REQUIRED_FIELDS: FieldName[] = [
  'name',
  'gender',
  'birth',
  'idno',
  'mobile',
  'email',
  'email2',
  'role',
  'session',
  'people',
  'arrive',
  'shuttle',
  'meal',
  'source',
  'agree',
];

/** 依身分別／人數／接駁需求追加的必填欄位 */
export const EXTRA_FIELDS: FieldName[] = [
  'school',
  'dept',
  'grade',
  'company',
  'jobTitle',
  'roleNote',
  'shuttleStop',
  'companions',
];
