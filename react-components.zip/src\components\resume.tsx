import type { CSSProperties } from 'react';
import type {
  KeyValueItem,
  ProjectData,
  SkillItem,
  StageItem,
  TagItem,
  TimelineEntry,
} from '../types';

/* ---------------- 經歷 ---------------- */

export function TimelineItem({ period, title, org, bullets }: TimelineEntry) {
  return (
    <li>
      <p className="when">{period}</p>
      <h3>{title}</h3>
      <p className="org">{org}</p>
      <ul>
        {bullets.map((bullet) => (
          <li key={bullet}>{bullet}</li>
        ))}
      </ul>
    </li>
  );
}

/* ---------------- 專案 ---------------- */

export function StageCard({ label, text }: StageItem) {
  return (
    <div className="stage">
      <b>{label}</b>
      <span>{text}</span>
    </div>
  );
}

export function TagList({ items, style }: { items: TagItem[]; style?: CSSProperties }) {
  return (
    <ul className="taglist" style={style}>
      {items.map((item) => (
        <li key={item.text} className={item.key ? 'key' : undefined}>
          {item.text}
        </li>
      ))}
    </ul>
  );
}

export function ProjectCard({ title, meta, paragraphs, stages, tags }: ProjectData) {
  return (
    <article className="proj">
      <h3>{title}</h3>
      <p className="meta">{meta}</p>
      {paragraphs.map((paragraph) => (
        <p key={paragraph}>{paragraph}</p>
      ))}
      {stages && stages.length > 0 && (
        <div className="stages">
          {stages.map((stage) => (
            <StageCard key={stage.label} {...stage} />
          ))}
        </div>
      )}
      {tags && tags.length > 0 && <TagList items={tags} style={{ marginTop: 12 }} />}
    </article>
  );
}

/* ---------------- 技能 ---------------- */

export function SkillRow({ category, detail }: SkillItem) {
  return (
    <div className="skillrow">
      <b>{category}</b>
      <span>{detail}</span>
    </div>
  );
}

/* ---------------- 側欄的定義清單 ---------------- */

export function KeyValueList({ items }: { items: KeyValueItem[] }) {
  return (
    <dl className="contact">
      {items.map((item) => (
        <div key={item.term}>
          <dt>{item.term}</dt>
          <dd>
            {item.lines ? (
              item.lines.map((line, index) => (
                <span key={line}>
                  {line}
                  {index < item.lines!.length - 1 && <br />}
                </span>
              ))
            ) : item.href ? (
              <a href={item.href}>{item.value}</a>
            ) : (
              item.value
            )}
            {item.note && <>　<span className="tip">（{item.note}）</span></>}
          </dd>
        </div>
      ))}
    </dl>
  );
}
