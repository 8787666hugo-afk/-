import { useEffect, useState } from 'react';
import type { FormEvent } from 'react';
import type {
  AccessValue,
  ButtonSpec,
  FieldMessages,
  FieldName,
  Gender,
  IdType,
  MealValue,
  ResultData,
  RoleValue,
  ShuttleValue,
  SignupFormData,
  SourceValue,
} from '../types';
import {
  ACCESS_OPTIONS,
  createInitialForm,
  GENDER_OPTIONS,
  GRADE_OPTIONS,
  ID_TYPE_OPTIONS,
  MEAL_OPTIONS,
  ORDER,
  ROLE_OPTIONS,
  SCHOOL_SUGGESTIONS,
  SESSIONS,
  SHUTTLE_OPTIONS,
  SHUTTLE_STOP_OPTIONS,
  SOURCE_OPTIONS,
} from '../data';
import { progress, validate, validateAll } from '../lib/validation';
import { ageText, collectRecap, serialNo } from '../lib/format';
import { FormActions, PageTitle, SectionCard } from '../components/layout';
import { ChoiceChips, FormField, SessionOption } from '../components/form';
import { ErrorSummary, FieldMessage, ProgressBar } from '../components/feedback';
import { DonePanel } from '../components/done';

const cleanText = (value: string) => value.replace(/[<>]/g, '');
const cleanEmail = (value: string) =>
  value.replace(/[\s\u3000]/g, '').replace(/。/g, '.').replace(/＠/g, '@');

function formatMobile(raw: string): string {
  const digits = raw.replace(/\D/g, '').slice(0, 10);
  if (digits.length > 7) {
    return `${digits.slice(0, 4)}-${digits.slice(4, 7)}-${digits.slice(7)}`;
  }
  if (digits.length > 4) return `${digits.slice(0, 4)}-${digits.slice(4)}`;
  return digits;
}

export function SignupFormPage() {
  const [data, setData] = useState<SignupFormData>(createInitialForm);
  const [messages, setMessages] = useState<FieldMessages>({});
  const [touched, setTouched] = useState<Partial<Record<FieldName, boolean>>>({});
  const [showSummary, setShowSummary] = useState(false);
  const [status, setStatus] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [result, setResult] = useState<ResultData | null>(null);

  const touchedAny = Object.keys(touched).length > 0;

  /* 離開頁面提醒：填過但還沒送出 */
  useEffect(() => {
    if (!touchedAny || result) return undefined;
    const handler = (event: BeforeUnloadEvent) => {
      event.preventDefault();
      event.returnValue = '';
    };
    window.addEventListener('beforeunload', handler);
    return () => window.removeEventListener('beforeunload', handler);
  }, [touchedAny, result]);

  function update<K extends FieldName>(name: K, value: SignupFormData[K]) {
    const next: SignupFormData = { ...data, [name]: value };
    setData(next);
    setStatus('');
    setMessages((prev) => {
      const nextMessages: FieldMessages = {};
      for (const key of ORDER) {
        if (prev[key] !== undefined || touched[key]) {
          nextMessages[key] = validate(key, next);
        }
      }
      return nextMessages;
    });
  }

  function blur(name: FieldName) {
    setTouched((prev) => ({ ...prev, [name]: true }));
    setMessages((prev) => ({ ...prev, [name]: validate(name, data) }));
  }

  function jumpTo(field: FieldName) {
    const element = document.getElementById(field);
    if (!element) return;
    element.scrollIntoView({ behavior: 'smooth', block: 'center' });
    try {
      element.focus({ preventScroll: true });
    } catch {
      element.focus();
    }
  }

  function checkAll() {
    const { messages: nextMessages, errors } = validateAll(data);
    setMessages(nextMessages);
    setTouched(
      Object.fromEntries(ORDER.map((name) => [name, true])) as Partial<
        Record<FieldName, boolean>
      >,
    );
    setShowSummary(errors.length > 0);
    setStatus(errors.length ? '' : '全部欄位檢查通過，可以送出。');
    if (errors.length) window.setTimeout(() => jumpTo(errors[0].field), 0);
  }

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (submitting) return;

    const { messages: nextMessages, errors } = validateAll(data);
    setMessages(nextMessages);

    if (errors.length) {
      setShowSummary(true);
      setStatus('');
      window.setTimeout(() => jumpTo(errors[0].field), 0);
      return;
    }

    setShowSummary(false);
    setSubmitting(true);
    setStatus('正在處理，請勿重複點擊或關閉頁面。');

    window.setTimeout(() => {
      setResult({
        serial: serialNo(),
        stamp: new Date().toLocaleString('zh-TW', { hour12: false }),
        rows: collectRecap(data),
      });
      setSubmitting(false);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }, 600);
  }

  function handleReset() {
    if (touchedAny && !window.confirm('確定要清除已填寫的所有內容嗎？此動作無法復原。')) {
      return;
    }
    setData(createInitialForm());
    setMessages({});
    setTouched({});
    setShowSummary(false);
    setStatus('');
    setSubmitting(false);
  }

  function downloadJson() {
    if (!result) return;
    const payload = {
      報名編號: result.serial,
      送出時間: result.stamp,
      ...Object.fromEntries(result.rows.map((row) => [row.key, row.value])),
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], {
      type: 'application/json;charset=utf-8',
    });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = `${result.serial || 'signup'}.json`;
    document.body.appendChild(anchor);
    anchor.click();
    window.setTimeout(() => {
      URL.revokeObjectURL(url);
      anchor.remove();
    }, 0);
  }

  const errors = showSummary ? validateAll(data).errors : [];
  const percent = progress(data);

  const isStudent = data.role === '學生';
  const isWorker = data.role === '在職';
  const isOther = data.role === '其他' || data.role === '待業／轉職';
  const companionCount = Math.max(0, Number(data.people || 1) - 1);
  const ageLabel = ageText(data.birth);

  const idTip =
    data.idType === 'arc'
      ? '新式統一證號：1 字母 + 8/9 + 8 位數字；舊式：2 字母 + 8 位數字'
      : '格式：1 個英文字母 + 9 位數字，並會驗證檢查碼';

  function formatId(raw: string): string {
    const value = raw.toUpperCase().replace(/[^A-Z0-9]/g, '');
    const headLength = data.idType === 'arc' ? 2 : 1;
    const head = value.slice(0, headLength);
    const tail = value.slice(headLength).replace(/[^0-9]/g, '');
    return (head + tail).slice(0, 10);
  }

  /* ---------------- 送出完成 ---------------- */
  const doneActions: ButtonSpec[] = [
    { label: '列印／存成 PDF', variant: 'ghost', onClick: () => window.print() },
    { label: '下載 JSON', variant: 'ghost', onClick: downloadJson },
    { label: '再填一份', variant: 'primary', onClick: () => window.location.reload() },
  ];

  return (
    <>
      <PageTitle
        title="說明會表單"
        titleId="formTitle"
        subtitle="請完整填寫以下資料完成報名。標示「必填」的欄位為必要資訊，系統會在您輸入時即時檢查格式。"
      />

      {result ? (
        <DonePanel
          serial={result.serial}
          stamp={result.stamp}
          rows={result.rows}
          actions={doneActions}
        />
      ) : (
        <>
          <ProgressBar percent={percent} />

          <ErrorSummary items={errors} onJump={jumpTo} />

          <form id="form" noValidate autoComplete="on" onSubmit={handleSubmit}>
        {/* ============ 1 基本個資 ============ */}
        <SectionCard
          number={1}
          title="基本個人資料"
          hint="請以身分證件上的正式姓名填寫，以便製作名牌與研習證明。"
          titleId="sec-person"
        >
          <div className="grid">
            <FormField
              name="name"
              label="姓名"
              required
              value={data.name}
              placeholder="王小明"
              maxLength={30}
              autoComplete="name"
              tip="中文 2–15 字，或英文 2–30 字（可含空格與 ·）"
              message={messages.name}
              onChange={(value) => update('name', cleanText(String(value)))}
              onBlur={() => blur('name')}
            />

            <FormField
              name="nickname"
              label="英文姓名／暱稱"
              value={data.nickname}
              placeholder="Hugo Liu"
              maxLength={40}
              message={messages.nickname}
              onChange={(value) => update('nickname', cleanText(String(value)))}
              onBlur={() => blur('nickname')}
            />

            <ChoiceChips
              name="gender"
              legend="性別"
              required
              type="radio"
              options={GENDER_OPTIONS}
              value={data.gender}
              message={messages.gender}
              onChange={(value) => update('gender', value as Gender)}
              onBlur={() => blur('gender')}
            />

            <FormField
              name="birth"
              label="出生年月日"
              kind="date"
              required
              value={data.birth}
              tip={
                <>
                  年齡須滿 15 歲；系統會自動換算 <span>{ageLabel}</span>
                </>
              }
              message={messages.birth}
              onChange={(value) => update('birth', String(value))}
              onBlur={() => blur('birth')}
            />

            <ChoiceChips
              name="idType"
              legend="證號類型"
              required
              type="radio"
              options={ID_TYPE_OPTIONS}
              value={data.idType}
              message={messages.idType}
              onChange={(value) => update('idType', value as IdType)}
              onBlur={() => blur('idType')}
            />

            <FormField
              name="idno"
              label="證件號碼"
              required
              value={data.idno}
              placeholder="A123456789"
              maxLength={10}
              spellCheck={false}
              tip={idTip}
              message={messages.idno}
              onChange={(value) => update('idno', formatId(String(value)))}
              onBlur={() => blur('idno')}
            />

            <FormField
              name="mobile"
              label="手機號碼"
              kind="tel"
              required
              value={data.mobile}
              placeholder="0912-345-678"
              maxLength={11}
              inputMode="numeric"
              autoComplete="tel"
              tip="台灣手機 09 開頭共 10 碼，輸入時自動加上連字號"
              message={messages.mobile}
              onChange={(value) => update('mobile', formatMobile(String(value)))}
              onBlur={() => blur('mobile')}
            />

            <FormField
              name="phone"
              label="聯絡電話（市話）"
              kind="tel"
              value={data.phone}
              placeholder="04-2392-4505 #1234"
              maxLength={15}
              inputMode="numeric"
              message={messages.phone}
              onChange={(value) =>
                update('phone', String(value).replace(/[^0-9\-#＃\s()轉]/g, ''))
              }
              onBlur={() => blur('phone')}
            />

            <FormField
              name="email"
              label="電子信箱"
              kind="email"
              required
              value={data.email}
              placeholder="you@example.com"
              maxLength={80}
              inputMode="email"
              autoComplete="email"
              spellCheck={false}
              tip="報名確認信將寄到此信箱，請確認拼字正確"
              message={messages.email}
              onChange={(value) => update('email', cleanEmail(String(value)))}
              onBlur={() => blur('email')}
            />

            <FormField
              name="email2"
              label="再次確認電子信箱"
              kind="email"
              required
              value={data.email2}
              placeholder="請再輸入一次"
              maxLength={80}
              inputMode="email"
              spellCheck={false}
              blockPaste
              tip="為避免打錯，此欄位不可貼上"
              message={messages.email2}
              onChange={(value) => update('email2', cleanEmail(String(value)))}
              onBlur={() => blur('email2')}
            />

            <FormField
              name="emergency"
              label="緊急聯絡人／電話"
              full
              value={data.emergency}
              placeholder="王大明 0987-654-321"
              maxLength={40}
              message={messages.emergency}
              onChange={(value) => update('emergency', cleanText(String(value)))}
              onBlur={() => blur('emergency')}
            />
          </div>
        </SectionCard>

        {/* ============ 2 學校／單位 ============ */}
        <SectionCard
          number={2}
          title="學校／單位資訊"
          hint="選擇身分別後，下方欄位會自動切換為對應的必填項目。"
          titleId="sec-org"
        >
          <div className="grid">
            <ChoiceChips
              name="role"
              legend="身分別"
              required
              full
              type="radio"
              options={ROLE_OPTIONS}
              value={data.role}
              message={messages.role}
              onChange={(value) => update('role', value as RoleValue)}
              onBlur={() => blur('role')}
            />

            {isStudent && (
              <>
                <FormField
                  name="school"
                  label="學校名稱"
                  required
                  value={data.school}
                  placeholder="國立勤益科技大學"
                  maxLength={40}
                  suggestions={SCHOOL_SUGGESTIONS}
                  message={messages.school}
                  onChange={(value) => update('school', cleanText(String(value)))}
                  onBlur={() => blur('school')}
                />

                <FormField
                  name="dept"
                  label="系所"
                  required
                  value={data.dept}
                  placeholder="資訊管理系"
                  maxLength={40}
                  message={messages.dept}
                  onChange={(value) => update('dept', cleanText(String(value)))}
                  onBlur={() => blur('dept')}
                />

                <FormField
                  name="grade"
                  label="年級"
                  kind="select"
                  required
                  value={data.grade}
                  options={GRADE_OPTIONS}
                  message={messages.grade}
                  onChange={(value) => update('grade', String(value))}
                  onBlur={() => blur('grade')}
                />

                <FormField
                  name="studentId"
                  label="學號"
                  value={data.studentId}
                  placeholder="s1234567"
                  maxLength={20}
                  spellCheck={false}
                  message={messages.studentId}
                  onChange={(value) => update('studentId', cleanText(String(value)))}
                  onBlur={() => blur('studentId')}
                />
              </>
            )}

            {isWorker && (
              <>
                <FormField
                  name="company"
                  label="公司／單位名稱"
                  required
                  value={data.company}
                  placeholder="泓記精密股份有限公司"
                  maxLength={50}
                  message={messages.company}
                  onChange={(value) => update('company', cleanText(String(value)))}
                  onBlur={() => blur('company')}
                />

                <FormField
                  name="jobTitle"
                  label="職稱"
                  required
                  value={data.jobTitle}
                  placeholder="資訊部專員"
                  maxLength={40}
                  message={messages.jobTitle}
                  onChange={(value) => update('jobTitle', cleanText(String(value)))}
                  onBlur={() => blur('jobTitle')}
                />

                <FormField
                  name="years"
                  label="相關工作年資"
                  kind="number"
                  value={data.years}
                  placeholder="3"
                  min={0}
                  max={60}
                  step={1}
                  tip="請填 0–60 之間的整數"
                  message={messages.years}
                  onChange={(value) => update('years', String(value))}
                  onBlur={() => blur('years')}
                />
              </>
            )}

            {isOther && (
              <FormField
                name="roleNote"
                label="身分別說明"
                required
                value={data.roleNote}
                placeholder="例如：自由工作者、家長"
                maxLength={40}
                message={messages.roleNote}
                onChange={(value) => update('roleNote', cleanText(String(value)))}
                onBlur={() => blur('roleNote')}
              />
            )}
          </div>
        </SectionCard>

        {/* ============ 3 場次 ============ */}
        <SectionCard
          number={3}
          title="說明會場次與時間"
          hint="請選擇一個場次；額滿場次無法選取。報到時間為開始前 30 分鐘。"
          titleId="sec-session"
        >
          <div
            className="sessions"
            id="sessionGroup"
            role="radiogroup"
            aria-labelledby="sec-session"
          >
            {SESSIONS.map((session) => (
              <SessionOption
                key={session.code}
                session={session}
                checked={data.session === session.value}
                onChange={(value) => update('session', value)}
                onBlur={() => blur('session')}
              />
            ))}
          </div>

          <div style={{ marginTop: 8 }}>
            <FieldMessage name="session" message={messages.session} />
          </div>

          <div className="grid" style={{ marginTop: 16 }}>
            <FormField
              name="people"
              label="參加人數（含本人）"
              kind="number"
              required
              value={data.people}
              min={1}
              max={5}
              step={1}
              tip="每筆報名最多 5 人；超過請分次報名"
              message={messages.people}
              onChange={(value) =>
                update('people', String(value).replace(/\D/g, '').slice(0, 1))
              }
              onBlur={() => blur('people')}
            />

            {companionCount > 0 && (
              <FormField
                name="companions"
                label="同行者姓名"
                required
                value={data.companions}
                placeholder="以頓號分隔，例如：李小華、張小美"
                maxLength={80}
                tip={
                  <>
                    需填寫 <b>{companionCount}</b> 位同行者姓名
                  </>
                }
                message={messages.companions}
                onChange={(value) => update('companions', cleanText(String(value)))}
                onBlur={() => blur('companions')}
              />
            )}

            <FormField
              name="arrive"
              label="預計抵達時間"
              kind="time"
              required
              value={data.arrive}
              tip="建議 09:00–14:00 之間；線上場可填預計上線時間"
              message={messages.arrive}
              onChange={(value) => update('arrive', String(value))}
              onBlur={() => blur('arrive')}
            />

            <ChoiceChips
              name="shuttle"
              legend="是否需要接駁車"
              required
              type="radio"
              options={SHUTTLE_OPTIONS}
              value={data.shuttle}
              message={messages.shuttle}
              onChange={(value) => update('shuttle', value as ShuttleValue)}
              onBlur={() => blur('shuttle')}
            />

            {data.shuttle === '需要' && (
              <FormField
                name="shuttleStop"
                label="接駁上車地點"
                kind="select"
                required
                full
                value={data.shuttleStop}
                options={SHUTTLE_STOP_OPTIONS}
                message={messages.shuttleStop}
                onChange={(value) => update('shuttleStop', String(value))}
                onBlur={() => blur('shuttleStop')}
              />
            )}
          </div>
        </SectionCard>

        {/* ============ 4 其他需求 ============ */}
        <SectionCard
          number={4}
          title="其他需求與問卷"
          hint="協助我們準備餐點與場地服務，選填欄位可留空。"
          titleId="sec-extra"
        >
          <div className="grid">
            <FormField
              name="meal"
              label="餐點需求"
              kind="select"
              required
              value={data.meal}
              options={MEAL_OPTIONS}
              message={messages.meal}
              onChange={(value) => update('meal', String(value) as MealValue)}
              onBlur={() => blur('meal')}
            />

            <FormField
              name="access"
              label="無障礙／場地協助需求"
              kind="select"
              value={data.access}
              options={ACCESS_OPTIONS}
              message={messages.access}
              onChange={(value) => update('access', String(value) as AccessValue)}
              onBlur={() => blur('access')}
            />

            <ChoiceChips
              name="source"
              legend="如何得知本次說明會（可多選，至少 1 項）"
              required
              full
              type="checkbox"
              options={SOURCE_OPTIONS}
              values={data.source}
              message={messages.source}
              onChange={(value, checked) => {
                const next = checked
                  ? [...data.source, value as SourceValue]
                  : data.source.filter((item) => item !== value);
                update('source', next);
              }}
              onBlur={() => blur('source')}
            />

            <FormField
              name="note"
              label="想了解的主題或備註"
              kind="textarea"
              full
              value={data.note}
              placeholder="例如：想了解 SAP 模組實習內容、是否提供研習證明…"
              maxLength={300}
              counter={
                <div className={data.note.length > 300 ? 'counter over' : 'counter'}>
                  {data.note.length} / 300
                </div>
              }
              message={messages.note}
              onChange={(value) => update('note', String(value))}
              onBlur={() => blur('note')}
            />
          </div>
        </SectionCard>

        {/* ============ 5 個資同意 ============ */}
        <SectionCard number={5} title="個人資料告知事項" titleId="sec-privacy">
          <article className="policy" tabIndex={0} aria-labelledby="sec-privacy">
            <p style={{ marginTop: 0 }}>
              <b>蒐集目的：</b>
              辦理本次說明會報名、報到、名牌與研習證明製作、活動通知及後續問卷調查。
            </p>
            <p>
              <b>個人資料類別：</b>
              姓名、性別、出生年月日、證件號碼、聯絡電話、電子信箱、學校或服務單位、餐點與場地需求。
            </p>
            <p>
              <b>利用期間與方式：</b>
              自蒐集日起至活動結束後一年內，以電子檔或紙本形式供主辦單位內部作業使用，不對外提供，屆期銷毀。
            </p>
            <p>
              <b>您的權利：</b>
              依個人資料保護法第 3 條，您得向主辦單位請求查詢、閱覽、複本、補充更正、停止處理利用或刪除個人資料。
            </p>
            <p style={{ marginBottom: 0 }}>
              <b>拒絕提供之影響：</b>
              若不提供必要資料，將無法完成報名手續。
            </p>
          </article>

          <FormField
            name="agree"
            label="個資同意"
            kind="checkbox"
            required
            value={data.agree}
            checkboxLabel="我已閱讀並同意上述個人資料告知事項，並確認所填資料真實無誤。"
            message={messages.agree}
            onChange={(value) => update('agree', Boolean(value))}
            onBlur={() => blur('agree')}
          />

          <div style={{ marginTop: 8 }}>
            <FormField
              name="news"
              label="訂閱活動資訊"
              kind="checkbox"
              value={data.news}
              checkboxLabel="我願意收到主辦單位後續活動與課程資訊（選填）"
              message={messages.news}
              onChange={(value) => update('news', Boolean(value))}
              onBlur={() => blur('news')}
            />
          </div>
        </SectionCard>

        <FormActions
          className="no-print"
          status={status}
          buttons={[
            {
              label: submitting ? '送出中…' : '送出報名',
              variant: 'primary',
              type: 'submit',
              disabled: submitting,
            },
            { label: '先檢查表單', variant: 'ghost', onClick: checkAll },
            { label: '清除重填', variant: 'ghost', onClick: handleReset },
          ]}
        />
          </form>
        </>
      )}
    </>
  );
}
