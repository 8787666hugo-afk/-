import { EXTRA_FIELDS, FIELD_LABELS, ORDER, REQUIRED_FIELDS } from '../data';
import type {
  ErrorItem,
  FieldMessageData,
  FieldMessages,
  FieldName,
  SignupFormData,
} from '../types';
import { ageOf } from './format';

/* ---------- 台灣身分證 / 統一證號檢查碼 ---------- */
const LET: Record<string, number> = {
  A: 10, B: 11, C: 12, D: 13, E: 14, F: 15, G: 16, H: 17, I: 34, J: 18,
  K: 19, L: 20, M: 21, N: 22, O: 35, P: 23, Q: 24, R: 25, S: 26, T: 27,
  U: 28, V: 29, W: 32, X: 30, Y: 31, Z: 33,
};

function idChecksum(letterVal: number, digits: string): boolean {
  let sum = Math.floor(letterVal / 10) + (letterVal % 10) * 9;
  for (let i = 0; i < 8; i += 1) sum += Number(digits[i]) * (8 - i);
  sum += Number(digits[8]);
  return sum % 10 === 0;
}

function validTwId(s: string): boolean {
  if (!/^[A-Z][12]\d{8}$/.test(s)) return false;
  return idChecksum(LET[s[0]], s.slice(1));
}

function validArc(s: string): boolean {
  if (/^[A-Z][89]\d{8}$/.test(s)) return idChecksum(LET[s[0]], s.slice(1));
  if (/^[A-Z]{2}\d{8}$/.test(s)) {
    return idChecksum(LET[s[0]], String(LET[s[1]] % 10) + s.slice(2));
  }
  return false;
}

const COMMON_DOMAINS = [
  'gmail.com',
  'yahoo.com.tw',
  'yahoo.com',
  'hotmail.com',
  'outlook.com',
  'icloud.com',
  'msn.com',
];

const TYPO: Record<string, string> = {
  'gmial.com': 'gmail.com',
  'gmai.com': 'gmail.com',
  'gmail.con': 'gmail.com',
  'gmail.cm': 'gmail.com',
  'gamil.com': 'gmail.com',
  'yaho.com': 'yahoo.com',
  'hotmai.com': 'hotmail.com',
  'outlok.com': 'outlook.com',
  'gmail.com.tw': 'gmail.com',
};

function text(d: SignupFormData, name: FieldName): string {
  const v = d[name];
  return v == null ? '' : String(v).trim();
}

/** 依身分別／人數／接駁需求決定欄位是否可見 */
export function isVisible(name: FieldName, d: SignupFormData): boolean {
  switch (name) {
    case 'school':
    case 'dept':
    case 'grade':
    case 'studentId':
      return d.role === '學生';
    case 'company':
    case 'jobTitle':
    case 'years':
      return d.role === '在職';
    case 'roleNote':
      return d.role === '其他' || d.role === '待業／轉職';
    case 'companions':
      return Number(text(d, 'people') || 1) > 1;
    case 'shuttleStop':
      return d.shuttle === '需要';
    default:
      return true;
  }
}

/** 單一欄位驗證；回傳 null 表示沒有問題 */
export function validate(name: FieldName, d: SignupFormData): FieldMessageData | null {
  switch (name) {
    case 'name': {
      const v = text(d, 'name');
      if (!v) return { type: 'error', text: '請填寫姓名' };
      if (/\d/.test(v)) return { type: 'error', text: '姓名不可包含數字' };
      if (/[!@#$%^&*()_+=\[\]{};:"\\|,<>\/?]/.test(v)) {
        return { type: 'error', text: '姓名不可包含特殊符號' };
      }
      const isCJK = /[\u4e00-\u9fff]/.test(v);
      if (isCJK) {
        if (!/^[\u4e00-\u9fff・·\s]{2,15}$/.test(v)) {
          return { type: 'error', text: '中文姓名請填 2–15 個中文字' };
        }
      } else if (!/^[A-Za-z][A-Za-z\s.'-]{1,29}$/.test(v)) {
        return { type: 'error', text: '英文姓名請填 2–30 個英文字母' };
      }
      return { type: 'good', text: '格式正確' };
    }

    case 'nickname': {
      const v = text(d, 'nickname');
      if (!v) return null;
      if (!/^[A-Za-z\u4e00-\u9fff][A-Za-z\u4e00-\u9fff\s.'-]{0,39}$/.test(v)) {
        return { type: 'error', text: '請勿使用特殊符號' };
      }
      return null;
    }

    case 'gender':
      return d.gender ? null : { type: 'error', text: '請選擇性別' };

    case 'birth': {
      const v = text(d, 'birth');
      if (!v) return { type: 'error', text: '請選擇出生年月日' };
      const date = new Date(`${v}T00:00:00`);
      if (Number.isNaN(date.getTime())) return { type: 'error', text: '日期格式不正確' };
      const a = ageOf(v);
      if (a === null) return { type: 'error', text: '日期格式不正確' };
      if (date > new Date()) return { type: 'error', text: '出生日期不可晚於今天' };
      if (a < 15) return { type: 'error', text: '本活動限滿 15 歲以上報名' };
      if (a > 100) return { type: 'error', text: '請確認出生年份是否正確' };

      const g = d.gender;
      const idv = text(d, 'idno').toUpperCase();
      if (/^[A-Z][12]/.test(idv) && (g === '男' || g === '女')) {
        const idG = idv[1] === '1' ? '男' : '女';
        if (idG !== g) {
          return { type: 'warn', text: '身分證號第 2 碼與所選性別不一致，請再確認' };
        }
      }
      return { type: 'good', text: `滿 ${a} 歲，符合資格` };
    }

    case 'idType':
      return null;

    case 'idno': {
      const v = text(d, 'idno').toUpperCase();
      if (!v) return { type: 'error', text: '請填寫證件號碼' };
      if (v.length !== 10) {
        return { type: 'error', text: `證號應為 10 碼，目前 ${v.length} 碼` };
      }
      if (d.idType === 'id') {
        if (!/^[A-Z]/.test(v)) return { type: 'error', text: '第 1 碼須為英文字母' };
        if (!/^[A-Z][12]\d{8}$/.test(v)) {
          return { type: 'error', text: '第 2 碼須為 1（男）或 2（女），其後 8 碼為數字' };
        }
        if (!validTwId(v)) {
          return { type: 'error', text: '檢查碼錯誤，請確認號碼是否輸入正確' };
        }
      } else if (!validArc(v)) {
        return { type: 'error', text: '居留證／統一證號格式或檢查碼錯誤' };
      }
      return { type: 'good', text: '證號驗證通過' };
    }

    case 'mobile': {
      const v = text(d, 'mobile').replace(/\D/g, '');
      if (!v) return { type: 'error', text: '請填寫手機號碼' };
      if (!/^09\d{8}$/.test(v)) return { type: 'error', text: '手機須為 09 開頭共 10 碼數字' };
      if (/^(\d)\1{9}$/.test(v)) return { type: 'error', text: '號碼看起來不正確' };
      return { type: 'good', text: '格式正確' };
    }

    case 'phone': {
      const raw = text(d, 'phone');
      if (!raw) return null;
      const v = raw.replace(/[\s()#＃-]/g, '').replace(/轉/g, '');
      if (!/^0\d{7,12}$/.test(v)) {
        return { type: 'error', text: '市話請填區碼＋號碼，例如 04-23924505' };
      }
      return null;
    }

    case 'email': {
      const v = text(d, 'email');
      if (!v) return { type: 'error', text: '請填寫電子信箱' };
      if (/\s/.test(v)) return { type: 'error', text: '電子信箱不可有空白' };
      if (!/^[A-Za-z0-9._%+-]+@[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)+$/.test(v)) {
        return { type: 'error', text: '電子信箱格式不正確，需包含 @ 與網域' };
      }
      if (/\.\./.test(v)) return { type: 'error', text: '電子信箱不可有連續兩個點' };
      const dom = v.split('@')[1].toLowerCase();
      if (TYPO[dom]) {
        return {
          type: 'warn',
          text: `您是不是想輸入 ${v.split('@')[0]}@${TYPO[dom]}？`,
        };
      }
      if (!/\.[A-Za-z]{2,}$/.test(dom)) return { type: 'error', text: '網域結尾不正確' };
      return {
        type: 'good',
        text: COMMON_DOMAINS.includes(dom) ? '格式正確' : `格式正確（${dom}）`,
      };
    }

    case 'email2': {
      const a = text(d, 'email').toLowerCase();
      const b = text(d, 'email2').toLowerCase();
      if (!b) return { type: 'error', text: '請再次輸入電子信箱' };
      if (a !== b) return { type: 'error', text: '兩次輸入的電子信箱不一致' };
      return { type: 'good', text: '兩次輸入一致' };
    }

    case 'emergency': {
      const v = text(d, 'emergency');
      if (!v) return null;
      if (v.replace(/\D/g, '').length < 8) {
        return { type: 'warn', text: '建議一併填寫聯絡電話' };
      }
      return null;
    }

    case 'role':
      return d.role ? null : { type: 'error', text: '請選擇身分別' };

    case 'school': {
      if (!isVisible('school', d)) return null;
      const v = text(d, 'school');
      if (!v) return { type: 'error', text: '請填寫學校名稱' };
      if (v.length < 2) return { type: 'error', text: '學校名稱至少 2 個字' };
      return { type: 'good', text: '已填寫' };
    }

    case 'dept': {
      if (!isVisible('dept', d)) return null;
      const v = text(d, 'dept');
      if (!v) return { type: 'error', text: '請填寫系所名稱' };
      if (v.length < 2) return { type: 'error', text: '系所名稱至少 2 個字' };
      return null;
    }

    case 'grade':
      if (!isVisible('grade', d)) return null;
      return text(d, 'grade') ? null : { type: 'error', text: '請選擇年級' };

    case 'studentId': {
      if (!isVisible('studentId', d)) return null;
      const v = text(d, 'studentId');
      if (!v) return null;
      if (!/^[A-Za-z0-9]{4,20}$/.test(v)) {
        return { type: 'error', text: '學號僅能是 4–20 位英數字' };
      }
      return null;
    }

    case 'company': {
      if (!isVisible('company', d)) return null;
      const v = text(d, 'company');
      if (!v) return { type: 'error', text: '請填寫公司／單位名稱' };
      if (v.length < 2) return { type: 'error', text: '名稱至少 2 個字' };
      return null;
    }

    case 'jobTitle':
      if (!isVisible('jobTitle', d)) return null;
      return text(d, 'jobTitle') ? null : { type: 'error', text: '請填寫職稱' };

    case 'years': {
      if (!isVisible('years', d)) return null;
      const v = text(d, 'years');
      if (v === '') return null;
      if (!/^\d+$/.test(v)) return { type: 'error', text: '年資請填整數' };
      const n = Number(v);
      if (n < 0 || n > 60) return { type: 'error', text: '年資請介於 0–60 之間' };
      return null;
    }

    case 'roleNote':
      if (!isVisible('roleNote', d)) return null;
      return text(d, 'roleNote') ? null : { type: 'error', text: '請簡述您的身分別' };

    case 'session':
      return d.session
        ? { type: 'good', text: '已選擇場次' }
        : { type: 'error', text: '請選擇一個場次' };

    case 'people': {
      const v = text(d, 'people');
      if (v === '') return { type: 'error', text: '請填寫參加人數' };
      if (!/^\d+$/.test(v)) return { type: 'error', text: '人數請填整數' };
      const n = Number(v);
      if (n < 1) return { type: 'error', text: '人數至少 1 人' };
      if (n > 5) return { type: 'error', text: '每筆報名最多 5 人' };
      if (d.session.startsWith('B｜') && n > 3) {
        return { type: 'error', text: 'B 場僅剩 3 個名額' };
      }
      return null;
    }

    case 'companions': {
      if (!isVisible('companions', d)) return null;
      const need = Math.max(0, Number(text(d, 'people') || 1) - 1);
      const list = text(d, 'companions')
        .split(/[、,，;；\s]+/)
        .filter(Boolean);
      if (!list.length) return { type: 'error', text: `請填寫 ${need} 位同行者姓名` };
      if (list.length !== need) {
        return { type: 'error', text: `需填 ${need} 位，目前填了 ${list.length} 位` };
      }
      if (list.some((n) => n.length < 2)) {
        return { type: 'error', text: '每位同行者姓名至少 2 個字' };
      }
      return { type: 'good', text: `已填 ${need} 位同行者` };
    }

    case 'arrive': {
      const v = text(d, 'arrive');
      if (!v) return { type: 'error', text: '請填寫預計抵達時間' };
      const [h, m] = v.split(':').map(Number);
      const mins = h * 60 + m;
      if (mins < 7 * 60 || mins > 18 * 60) {
        return { type: 'error', text: '請填 07:00–18:00 之間的時間' };
      }
      if (d.session.startsWith('A｜') || d.session.startsWith('C｜')) {
        if (mins > 10 * 60) {
          return { type: 'warn', text: '本場次 10:00 開始，建議提早抵達報到' };
        }
      } else if (d.session.startsWith('B｜') && mins > 14 * 60) {
        return { type: 'warn', text: '本場次 14:00 開始，建議提早抵達報到' };
      }
      return { type: 'good', text: '已填寫' };
    }

    case 'shuttle':
      return d.shuttle
        ? null
        : { type: 'error', text: '請選擇是否需要接駁車' };

    case 'shuttleStop':
      if (!isVisible('shuttleStop', d)) return null;
      return text(d, 'shuttleStop') ? null : { type: 'error', text: '請選擇上車地點' };

    case 'meal':
      return d.meal ? null : { type: 'error', text: '請選擇餐點需求' };

    case 'access':
      return null;

    case 'source':
      return d.source.length ? null : { type: 'error', text: '請至少勾選 1 項得知管道' };

    case 'note': {
      const v = text(d, 'note');
      if (d.meal.startsWith('其他') && v.length < 5) {
        return { type: 'error', text: '餐點需求選「其他」時，請在備註說明（至少 5 字）' };
      }
      if (d.access.startsWith('其他') && v.length < 5) {
        return { type: 'error', text: '無障礙需求選「其他」時，請在備註說明（至少 5 字）' };
      }
      if (v.length > 300) return { type: 'error', text: '備註最多 300 字' };
      return null;
    }

    case 'agree':
      return d.agree ? null : { type: 'error', text: '請勾選同意個人資料告知事項' };

    case 'news':
      return null;

    default:
      return null;
  }
}

export interface ValidationResult {
  messages: FieldMessages;
  errors: ErrorItem[];
}

/** 跑全部欄位：給「先檢查表單」與送出使用 */
export function validateAll(d: SignupFormData): ValidationResult {
  const messages: FieldMessages = {};
  const errors: ErrorItem[] = [];

  for (const name of ORDER) {
    const result = validate(name, d);
    if (result) messages[name] = result;
    if (result?.type === 'error') {
      errors.push({ field: name, label: FIELD_LABELS[name], message: result.text });
    }
  }

  return { messages, errors };
}

/** 完成度：固定必填 + 目前可見的追加必填 */
export function progress(d: SignupFormData): number {
  const fields = [
    ...REQUIRED_FIELDS,
    ...EXTRA_FIELDS.filter((name) => isVisible(name, d)),
  ];
  const done = fields.filter((name) => {
    const result = validate(name, d);
    return !result || result.type !== 'error';
  }).length;
  return Math.round((done / fields.length) * 100);
}
