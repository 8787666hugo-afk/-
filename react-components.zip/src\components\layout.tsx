import type { ReactNode } from 'react';
import type { ButtonSpec, NavItem } from '../types';

/* ---------------- 站頭 ---------------- */

export interface SiteHeaderProps {
  logoText: string;
  name: string;
  tagline: string;
  homeHref?: string;
  items: NavItem[];
}

export function SiteHeader({
  logoText,
  name,
  tagline,
  homeHref = '#/home',
  items,
}: SiteHeaderProps) {
  return (
    <header className="site-head">
      <div className="inner">
        <a className="brand" href={homeHref}>
          <span className="logo" aria-hidden="true">
            {logoText}
          </span>
          <span>
            <b>{name}</b>
            <span>{tagline}</span>
          </span>
        </a>
        <nav className="tabs" aria-label="主要導覽">
          {items.map((item) => (
            <a
              key={item.href}
              href={item.href}
              id={item.id}
              aria-current={item.current ? 'page' : undefined}
            >
              {item.label}
            </a>
          ))}
        </nav>
      </div>
    </header>
  );
}

/* ---------------- 頁標題 ---------------- */

export interface PageTitleProps {
  title: string;
  subtitle?: string;
  titleId?: string;
}

export function PageTitle({ title, subtitle, titleId }: PageTitleProps) {
  return (
    <div className="page-title">
      <h1 id={titleId}>{title}</h1>
      {subtitle && <p>{subtitle}</p>}
    </div>
  );
}

/* ---------------- 內容卡 / 表單區段 ---------------- */

export interface SectionCardProps {
  /** 表單區段才需要編號 */
  number?: number;
  title: string;
  hint?: string;
  titleId?: string;
  className?: string;
  children: ReactNode;
}

export function SectionCard({
  number,
  title,
  hint,
  titleId,
  className,
  children,
}: SectionCardProps) {
  return (
    <section className={className ? `card ${className}` : 'card'} aria-labelledby={titleId}>
      <h2 id={titleId}>
        {number != null && <span className="num">{number}</span>}
        {title}
      </h2>
      {hint && <p className="hint">{hint}</p>}
      {children}
    </section>
  );
}

/* ---------------- 按鈕列 ---------------- */

export interface FormActionsProps {
  buttons: ButtonSpec[];
  status?: string;
  className?: string;
}

export function FormActions({ buttons, status, className }: FormActionsProps) {
  return (
    <div className={className ? `actions ${className}` : 'actions'}>
      {buttons.map((button) => (
        <button
          key={button.label}
          type={button.type ?? 'button'}
          className={button.variant === 'primary' ? 'btn-primary' : 'btn-ghost'}
          disabled={button.disabled}
          onClick={button.onClick}
        >
          {button.label}
        </button>
      ))}
      {status !== undefined && (
        <span className="tip" aria-live="polite">
          {status}
        </span>
      )}
    </div>
  );
}

/* ---------------- 頁尾 ---------------- */

export interface SiteFooterProps {
  year: number;
  name: string;
  email: string;
  note: string;
}

export function SiteFooter({ year, name, email, note }: SiteFooterProps) {
  return (
    <footer className="site-foot">
      <p>
        © {year} {name} ・ <a href={`mailto:${email}`}>{email}</a>
      </p>
      <p className="tip">{note}</p>
    </footer>
  );
}
