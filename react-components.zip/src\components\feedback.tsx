import type { ErrorItem, FieldMessageData, MessageType, Tone } from '../types';

const ICON: Record<MessageType, string> = {
  error: '⚠ ',
  warn: 'ℹ ',
  good: '✓ ',
};

/* ---------------- 欄位訊息 ---------------- */

export interface FieldMessageProps {
  name: string;
  message?: FieldMessageData | null;
}

export function FieldMessage({ name, message }: FieldMessageProps) {
  if (!message) {
    return <div className="msg" data-for={name} id={`msg-${name}`} />;
  }
  return (
    <div
      className={`msg show ${message.type}`}
      data-for={name}
      id={`msg-${name}`}
      role="status"
      aria-live="polite"
    >
      {ICON[message.type]}
      {message.text}
    </div>
  );
}

/* ---------------- 名額徽章 ---------------- */

const BADGE_CLASS: Record<Tone, string> = {
  ok: 'left',
  warn: 'few',
  danger: 'none',
};

export interface StatusBadgeProps {
  tone: Tone;
  text: string;
}

export function StatusBadge({ tone, text }: StatusBadgeProps) {
  return <span className={`badge ${BADGE_CLASS[tone]}`}>{text}</span>;
}

/* ---------------- 進度條 ---------------- */

export interface ProgressBarProps {
  percent: number;
  label?: string;
  id?: string;
}

export function ProgressBar({ percent, label = '完成度', id = 'prog' }: ProgressBarProps) {
  return (
    <div className="no-print">
      <p className="progress-label" id={`${id}Label`}>
        {label} <span>{percent}%</span>
      </p>
      <div
        className="progress"
        id={id}
        role="progressbar"
        aria-labelledby={`${id}Label`}
        aria-valuemin={0}
        aria-valuemax={100}
        aria-valuenow={percent}
        aria-valuetext={`必填欄位已完成 ${percent}%`}
      >
        <i style={{ width: `${percent}%` }} />
      </div>
    </div>
  );
}

/* ---------------- 錯誤摘要 ---------------- */

export interface ErrorSummaryProps {
  items: ErrorItem[];
  onJump?: (field: ErrorItem['field']) => void;
}

export function ErrorSummary({ items, onJump }: ErrorSummaryProps) {
  if (!items.length) return null;

  return (
    <nav
      className="summary-box show no-print"
      id="errBox"
      role="alert"
      aria-live="assertive"
      aria-labelledby="errTitle"
      tabIndex={-1}
    >
      <h2 id="errTitle">
        尚有 <span>{items.length}</span> 個欄位需要修正
      </h2>
      <ol>
        {items.map((item) => (
          <li key={item.field}>
            <a
              href={`#${item.field}`}
              onClick={(event) => {
                event.preventDefault();
                onJump?.(item.field);
              }}
            >
              {item.label}：{item.message}
            </a>
          </li>
        ))}
      </ol>
    </nav>
  );
}
