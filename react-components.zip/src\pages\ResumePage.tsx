import {
  CONTACT_ITEMS,
  EDUCATION_ITEMS,
  PROJECTS,
  SKILLS,
  TAGS,
  TIMELINE,
} from '../data';
import { PageTitle, SectionCard } from '../components/layout';
import {
  KeyValueList,
  ProjectCard,
  SkillRow,
  TagList,
  TimelineItem,
} from '../components/resume';

export function ResumePage() {
  return (
    <>
      <PageTitle
        title="個人簡介"
        subtitle="Curriculum Vitae ・ 最後更新 2026 年 9 月"
        titleId="resumeTitle"
      />

      <div className="resume-grid">
        <div>
          <SectionCard title="關於我" titleId="r-about">
            <p style={{ margin: 0, fontSize: 14 }}>
              我從高職電子科一路轉到資訊管理，習慣從系統層級思考問題：遇到錯誤時不接受繞過的做法，
              而是追到根本原因為止。這個習慣在 SAP 組織架構設定與跨系統整合上特別有用——
              多數卡關並不是操作錯誤，而是前置設定缺了一環。
            </p>
            <p style={{ margin: '10px 0 0', fontSize: 14 }}>
              目前專注在製造業的需求規劃領域，把 SAP 標準功能與外部訊號結合，
              讓預測結果既可解釋、又能反映真實市場事件。中程目標是進入 ERP 顧問領域。
            </p>
          </SectionCard>

          <SectionCard title="經歷" titleId="r-exp">
            <ol className="timeline">
              {TIMELINE.map((entry) => (
                <TimelineItem key={entry.title} {...entry} />
              ))}
            </ol>
          </SectionCard>

          <SectionCard
            title="代表專案"
            titleId="r-proj"
            hint="SAP S/4HANA 導入 ・ AI 輔助需求預測架構"
          >
            {PROJECTS.map((project) => (
              <ProjectCard key={project.title} {...project} />
            ))}
          </SectionCard>

          <SectionCard title="專業能力" titleId="r-skill">
            <div style={{ marginTop: 14 }}>
              {SKILLS.map((skill) => (
                <SkillRow key={skill.category} {...skill} />
              ))}
            </div>
          </SectionCard>
        </div>

        <aside className="side">
          <SectionCard title="聯絡方式" titleId="r-contact">
            <KeyValueList items={CONTACT_ITEMS} />
          </SectionCard>

          <SectionCard title="學歷與證照" titleId="r-edu">
            <KeyValueList items={EDUCATION_ITEMS} />
          </SectionCard>

          <SectionCard title="關鍵字" titleId="r-tags">
            <div style={{ marginTop: 12 }}>
              <TagList items={TAGS} />
            </div>
          </SectionCard>
        </aside>
      </div>
    </>
  );
}
