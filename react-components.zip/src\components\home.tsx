import type { ActionLink, Fact, NavCardData } from '../types';

/* ---------------- 首頁主視覺 ---------------- */

export interface HeroProps {
  avatarText: string;
  name: string;
  role: string;
  lede: string;
  actions: ActionLink[];
}

export function Hero({ avatarText, name, role, lede, actions }: HeroProps) {
  return (
    <div className="hero">
      <div className="avatar" aria-hidden="true">
        {avatarText}
      </div>
      <h1 id="homeTitle">{name}</h1>
      <p className="role">{role}</p>
      <p className="lede">{lede}</p>
      <div className="hero-cta">
        {actions.map((action) => (
          <a key={action.href} className={action.variant ?? 'ghost'} href={action.href}>
            {action.label}
          </a>
        ))}
      </div>
    </div>
  );
}

/* ---------------- 重點數字 ---------------- */

export function FactCard({ value, label }: Fact) {
  return (
    <div className="fact">
      <b>{value}</b>
      <span>{label}</span>
    </div>
  );
}

/* ---------------- 首頁導覽卡 ---------------- */

export function NavCard({ icon, title, description, cta, href }: NavCardData) {
  return (
    <a className="nav-card" href={href}>
      <div className="ico" aria-hidden="true">
        {icon}
      </div>
      <h3>{title}</h3>
      <p>{description}</p>
      <div className="go">{cta}</div>
    </a>
  );
}
