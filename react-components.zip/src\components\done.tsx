import type { ButtonSpec, RecapRow } from '../types';
import { FormActions } from './layout';

export interface RecapTableProps {
  rows: RecapRow[];
}

export function RecapTable({ rows }: RecapTableProps) {
  return (
    <table className="recap">
      <caption className="sr">您填寫的報名內容</caption>
      <tbody>
        {rows.map((row) => (
          <tr key={row.key}>
            <th>{row.key}</th>
            <td>{row.value}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

export interface DonePanelProps {
  serial: string;
  stamp: string;
  rows: RecapRow[];
  actions: ButtonSpec[];
}

export function DonePanel({ serial, stamp, rows, actions }: DonePanelProps) {
  return (
    <section
      className="card show"
      id="done"
      aria-live="polite"
      aria-labelledby="doneTitle"
      tabIndex={-1}
    >
      <div className="done-head">
        <span className="tick">✓</span>
        <div>
          <h2 style={{ margin: 0 }} id="doneTitle">
            報名資料已送出
          </h2>
          <p className="hint" style={{ margin: 0 }}>
            報名編號 <span className="code">{serial}</span>，送出時間 <span>{stamp}</span>
          </p>
        </div>
      </div>
      <p className="tip">
        以下為您填寫的內容，請確認無誤並自行保存。此頁為前端示範，資料僅顯示於本機、未上傳任何伺服器。
      </p>
      <RecapTable rows={rows} />
      <FormActions buttons={actions} className="no-print" />
    </section>
  );
}
