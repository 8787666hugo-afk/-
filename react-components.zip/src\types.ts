/* ============================================================
   共用資料模型
   ------------------------------------------------------------
   這個檔案不依賴 React。若之後要改成 Vue，型別可以直接沿用。
   ============================================================ */

export type MessageType = 'error' | 'warn' | 'good';

export interface FieldMessageData {
  type: MessageType;
  text: string;
}

/** 場次名額徽章：ok = 綠色、warn = 黃色、danger = 紅色 */
export type Tone = 'ok' | 'warn' | 'danger';

export type Gender = '男' | '女' | '不願透露' | '';
export type IdType = 'id' | 'arc';
export type RoleValue = '學生' | '在職' | '待業／轉職' | '其他' | '';
export type ShuttleValue = '需要' | '不需要' | '';
export type MealValue =
  | '葷食'
  | '素食'
  | '不需餐點'
  | '其他（請於下方備註說明）'
  | '';
export type AccessValue =
  | ''
  | '需要輪椅席位'
  | '需要前排座位'
  | '需要手語或字幕協助'
  | '其他（請於備註說明）';
export type SourceValue =
  | '學校公告'
  | '系所老師'
  | '社群媒體'
  | '朋友推薦'
  | '電子報'
  | '其他';

/** 表單的完整資料模型：31 個欄位 + 選填的訂閱 */
export interface SignupFormData {
  name: string;
  nickname: string;
  gender: Gender;
  birth: string;
  idType: IdType;
  idno: string;
  mobile: string;
  phone: string;
  email: string;
  email2: string;
  emergency: string;

  role: RoleValue;
  school: string;
  dept: string;
  grade: string;
  studentId: string;
  company: string;
  jobTitle: string;
  years: string;
  roleNote: string;

  session: string;
  people: string;
  companions: string;
  arrive: string;
  shuttle: ShuttleValue;
  shuttleStop: string;

  meal: MealValue;
  access: AccessValue;
  source: SourceValue[];
  note: string;

  agree: boolean;
  news: boolean;
}

export type FieldName = keyof SignupFormData;
export type FieldMessages = Partial<Record<FieldName, FieldMessageData | null>>;

export interface ErrorItem {
  field: FieldName;
  label: string;
  message: string;
}

/* ---------- 版面與內容元件 ---------- */

export interface NavItem {
  id?: string;
  label: string;
  href: string;
  current?: boolean;
}

export interface ActionLink {
  label: string;
  href: string;
  variant?: 'primary' | 'ghost';
}

export interface ButtonSpec {
  label: string;
  variant?: 'primary' | 'ghost';
  type?: 'button' | 'submit' | 'reset';
  disabled?: boolean;
  onClick?: () => void;
}

export interface Fact {
  value: string;
  label: string;
}

export interface NavCardData {
  icon: string;
  title: string;
  description: string;
  cta: string;
  href: string;
}

export interface TimelineEntry {
  period: string;
  title: string;
  org: string;
  bullets: string[];
}

export interface StageItem {
  label: string;
  text: string;
}

export interface TagItem {
  text: string;
  key?: boolean;
}

export interface ProjectData {
  title: string;
  meta: string;
  paragraphs: string[];
  stages?: StageItem[];
  tags?: TagItem[];
}

export interface SkillItem {
  category: string;
  detail: string;
}

export interface KeyValueItem {
  term: string;
  value?: string;
  href?: string;
  note?: string;
  lines?: string[];
}

/* ---------- 場次 ---------- */

export interface SessionBadge {
  tone: Tone;
  text: string;
}

export interface SessionData {
  code: string;
  /** 送出時使用的完整字串，沿用原檔格式 */
  value: string;
  title: string;
  location: string;
  badge: SessionBadge;
  disabled?: boolean;
}

/* ---------- 表單選項 ---------- */

export interface ChoiceOption {
  value: string;
  label: string;
  disabled?: boolean;
}

export interface SelectOption {
  value: string;
  label: string;
}

/* ---------- 完成畫面 ---------- */

export interface RecapRow {
  key: string;
  value: string;
}

export interface ResultData {
  rows: RecapRow[];
  serial: string;
  stamp: string;
}
