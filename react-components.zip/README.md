# 個人網站元件化版本（React + TypeScript）

把 `20261006.html`（劉育齊 Hugo 個人網站）拆成可重用的 React 元件。
版型與 CSS 完全沿用原檔，**class 名稱沒有改**，所以視覺結果與原本一致。

## 快速開始

```bash
npm install
npm run dev      # http://localhost:5173
npm run build    # TypeScript 檢查 + 產生 dist/
```

> 需求：Node.js 18 以上。

## 目錄

```
src/
  styles.css              由原檔 <style> 直接抽出，未改動
  types.ts                資料模型與所有元件的 props 型別（不依賴 React）
  data.ts                 所有可變內容：場次、選項、履歷、技能、標籤…
  lib/
    validation.ts         31 個欄位的驗證規則、錯誤摘要、完成度
    format.ts             年齡、證號遮罩、報名編號、完成畫面摘要
  components/
    layout.tsx            SiteHeader / PageTitle / SectionCard / FormActions / SiteFooter
    feedback.tsx          FieldMessage / StatusBadge / ProgressBar / ErrorSummary
    home.tsx              Hero / FactCard / NavCard
    resume.tsx            TimelineItem / ProjectCard / StageCard / SkillRow / TagList / KeyValueList
    form.tsx              FormField / ChoiceChips / SessionOption
    done.tsx              DonePanel / RecapTable
    index.ts              barrel export
  pages/
    HomePage.tsx
    ResumePage.tsx
    SignupFormPage.tsx    表單狀態、即時驗證、送出與完成畫面
  App.tsx                 hash 路由（#/home、#/resume、#/form）
  main.tsx
```

## 重複區塊 → 元件對照

| 元件 | 檔案 | 原本的標記 | 次數 | 可變資料 |
|---|---|---|---|---|
| `SectionCard` | layout.tsx | `.card` | 12 | `number?`、`title`、`hint?`、`children` |
| `FormField` | form.tsx | `.field` | 26 | `name`、`label`、`kind`、`required`、`value`、`options`、`tip`、`message`、`visible` |
| `FieldMessage` | feedback.tsx | `.msg` | 31 | `name`、`message: { type, text }` |
| `ChoiceChips` | form.tsx | `.choices` / `.chip` | 5 組 | `name`、`legend`、`type`、`options`、`value` / `values`、`message` |
| `SessionOption` | form.tsx | `label.session` | 4 | `session`（含 `title`、`location`、`badge`、`disabled`）、`checked` |
| `StatusBadge` | feedback.tsx | `.badge` | 4 | `tone`、`text` |
| `TimelineItem` | resume.tsx | `.timeline > li` | 4 | `period`、`title`、`org`、`bullets` |
| `ProjectCard` | resume.tsx | `article.proj` | 2 | `title`、`meta`、`paragraphs`、`stages?`、`tags?` |
| `StageCard` | resume.tsx | `.stage` | 3 | `label`、`text` |
| `SkillRow` | resume.tsx | `.skillrow` | 5 | `category`、`detail` |
| `TagList` | resume.tsx | `.taglist` | 2 組 | `items[{ text, key }]` |
| `FactCard` | home.tsx | `.fact` | 4 | `value`、`label` |
| `NavCard` | home.tsx | `a.nav-card` | 2 | `icon`、`title`、`description`、`cta`、`href` |
| `KeyValueList` | resume.tsx | `dl.contact` | 2 組 | `items[{ term, value, href?, note?, lines? }]` |
| `FormActions` | layout.tsx | `.actions` | 2 列 | `buttons[{ label, variant, type, disabled, onClick }]`、`status` |
| `PageTitle` | layout.tsx | `.page-title` | 2 | `title`、`subtitle`、`titleId` |
| `SiteHeader` | layout.tsx | `.site-head` | 1（外框） | `logoText`、`name`、`tagline`、`items` |
| `Hero` | home.tsx | `.hero` | 1 | `avatarText`、`name`、`role`、`lede`、`actions` |
| `ProgressBar` | feedback.tsx | `.progress` | 1 | `percent` |
| `ErrorSummary` | feedback.tsx | `.summary-box` | 1 | `items[{ field, label, message }]` |
| `DonePanel` | done.tsx | `#done` | 1 | `serial`、`stamp`、`rows`、`actions` |

## 資料流

```
createInitialForm() ──► SignupFormPage 的 data state
                              │
        ┌─────────────────────┼─────────────────────┐
        ▼                     ▼                     ▼
   FormField            ChoiceChips           SessionOption
        │                     │                     │
        └──────── update(name, value) ──────────────┘
                              │
                              ▼
                    validate(name, data)
                              │
                              ▼
                        messages state
                              │
              ┌───────────────┼───────────────┐
              ▼               ▼               ▼
        FieldMessage    ErrorSummary     ProgressBar
```

- `data`：31 個欄位的值，形狀是 `SignupFormData`。
- `messages`：每個欄位最新的 `{ type, text }`，只保留「碰過或已驗證」的欄位。
- `touched`：欄位是否被 blur 過，決定何時開始顯示訊息。
- 條件顯示（學生／在職／其他、同行者、接駁地點）由 `isVisible()` 與頁面條件共同決定。
- 進度條由 `progress(data)` 計算：固定 15 個必填 + 目前可見的追加必填。

## 想改內容時

| 想改的東西 | 改哪裡 |
|---|---|
| 場次、名額、額滿狀態 | `data.ts` → `SESSIONS` |
| 下拉選項、身分別、餐點 | `data.ts` → `*_OPTIONS` |
| 履歷、專案、技能、標籤 | `data.ts` → `TIMELINE`、`PROJECTS`、`SKILLS`、`TAGS` |
| 驗證規則 | `lib/validation.ts` → `validate()` |
| 完成畫面要顯示的欄位 | `lib/format.ts` → `collectRecap()` |
| 表單初始值 | `data.ts` → `createInitialForm()` |

## 與原檔的差異

1. **CSS 完全沿用**：`styles.css` 是從原檔 `<style>` 抽出的內容。
2. **DOM 操作改成 state**：年齡顯示、字數計數、同行者欄位、接駁地點、完成畫面都改成由資料推導。
3. **驗證規則照搬**：身分證／統一證號檢查碼、Email 錯字提示、B 場名額限制、備註與餐點的連動都保留。
4. **路由照舊**：使用 `#/home`、`#/resume`、`#/form`，整理成 `App.tsx`。
5. **列印與 JSON 下載**：完成畫面保留原本的兩個功能。

## 如果課堂用 Vue

`types.ts`、`data.ts`、`lib/validation.ts`、`lib/format.ts` 都不依賴 React，可以直接沿用。
只需要把 `components/*.tsx` 改寫成 `.vue` SFC，props 與事件介面已經定義在各自的 `interface` 裡，對照搬過去即可。
