import { useEffect, useState } from 'react';
import { NAV_ITEMS, SITE } from './data';
import { SiteFooter, SiteHeader } from './components/layout';
import { HomePage } from './pages/HomePage';
import { ResumePage } from './pages/ResumePage';
import { SignupFormPage } from './pages/SignupFormPage';

type Route = '#/home' | '#/resume' | '#/form';

const ROUTES: Route[] = ['#/home', '#/resume', '#/form'];

const TITLES: Record<Route, string> = {
  '#/home': '劉育齊 Hugo｜個人網站',
  '#/resume': '個人簡介｜劉育齊 Hugo',
  '#/form': '說明會表單｜劉育齊 Hugo',
};

function readRoute(): Route {
  const hash = window.location.hash as Route;
  return ROUTES.includes(hash) ? hash : '#/home';
}

export default function App() {
  const [route, setRoute] = useState<Route>(readRoute);

  useEffect(() => {
    if (!ROUTES.includes(window.location.hash as Route)) {
      window.history.replaceState(null, '', '#/home');
      setRoute('#/home');
    }

    const onHashChange = () => setRoute(readRoute());
    window.addEventListener('hashchange', onHashChange);
    return () => window.removeEventListener('hashchange', onHashChange);
  }, []);

  useEffect(() => {
    document.title = TITLES[route];
    window.scrollTo({ top: 0, behavior: 'smooth' });
    const heading = document.querySelector<HTMLElement>('.view.active h1');
    if (heading) {
      heading.setAttribute('tabindex', '-1');
      try {
        heading.focus({ preventScroll: true });
      } catch {
        heading.focus();
      }
    }
  }, [route]);

  const navItems = NAV_ITEMS.map((item) => ({
    ...item,
    current: item.href === route,
  }));

  return (
    <>
      <a
        href="#main"
        className="sr"
        onClick={(event) => {
          event.preventDefault();
          document.getElementById('main')?.focus();
        }}
      >
        跳到主要內容
      </a>

      <SiteHeader
        logoText={SITE.logoText}
        name={SITE.name}
        tagline={SITE.tagline}
        items={navItems}
      />

      <div className="wrap">
        <main id="main" tabIndex={-1}>
          <section
            className={`view ${route === '#/home' ? 'active' : ''}`}
            id="view-home"
            aria-labelledby="homeTitle"
          >
            <HomePage />
          </section>

          <section
            className={`view ${route === '#/resume' ? 'active' : ''}`}
            id="view-resume"
            aria-labelledby="resumeTitle"
          >
            <ResumePage />
          </section>

          <section
            className={`view ${route === '#/form' ? 'active' : ''}`}
            id="view-form"
            aria-labelledby="formTitle"
          >
            <SignupFormPage />
          </section>
        </main>

        <SiteFooter
          year={SITE.year}
          name={SITE.name}
          email={SITE.email}
          note={SITE.footerNote}
        />
      </div>
    </>
  );
}
