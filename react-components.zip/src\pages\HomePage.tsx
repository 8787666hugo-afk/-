import { FACTS, HERO, NAV_CARDS } from '../data';
import { FactCard, Hero, NavCard } from '../components/home';

export function HomePage() {
  return (
    <>
      <Hero {...HERO} />

      <div className="facts">
        {FACTS.map((fact) => (
          <FactCard key={fact.label} {...fact} />
        ))}
      </div>

      <h2 className="sr">網站導覽</h2>
      <div className="cards2" style={{ marginTop: 20 }}>
        {NAV_CARDS.map((card) => (
          <NavCard key={card.href} {...card} />
        ))}
      </div>
    </>
  );
}
